 $(document).ready(function() {
	$(document).keydown(function(e) {
		if (e.keyCode === 27) {
			e.stopPropagation();
			document.getElementById("my-cool-form").remove();
		}});      	


});
     function close_my_form(){
	    document.getElementById("my-cool-form").remove();
		return false;
};
function showform() {
    $( "#cool" )
  .html( `<div id="my-cool-form" class="popup-fade">
	<div id="popup" class="popup">
		<a class="popup-close" onClick="close_my_form()" >X</a>
		<div class="modal-dialog">
            <h1>Оформление заказа</h1>
        <div class="modal-content">
            <p>Оставьте заявку на сайте и наши операторы свяжутся с вами в течени 15 минут для уточнение вашего заказа!</p>
             <form id="order_form" class="my-cool-form" action="./content/index.php" method="post" target="_blank" onsubmit='return storeValues(this), disableButton()'>
				<input class="cool-form-field field-fio" id="fio" type="text" name="fio" required placeholder="Введите Ваше имя" >
				<input class="cool-form-field field-tel" id="tel" type="tel" name="tel" onkeyup="this.value = this.value.replace (/[^0-9+]/, '')"  pattern=".{8,}"  required title="9 characters minimum" required placeholder="Введите Ваш телефон" >
				<input type="hidden" id="subidid" name="subidid" value="">
                <input type="hidden"  id="refer" name="refer" value="" >
                <input type="hidden"  id="door" name="door"  value="">
                <input  type="hidden" id="token" name="token" value="" />
				<button class="cool-form-button" input type="submit" name="order">Оформить заказ</button>
            </form>
      </div>
	</div>		
</div>
</div>` );   
    $("#refer").val(subid);
    $("#door").val(door);
    $("#subidid").val(subidid);
     $("#token").val(token);
     var cname = getCookie("fio");
    var ctel = getCookie("tel");
    var csub = getCookie("sub");
    if ((cname !=null) && (ctel !=null) && (csub == subidid )) {
        
  disableButton();
}    
};
function disableButton() {
		var str = `<div class="replace">
<h1>Спасибо за заказ</h1>
<p>Имя: <b id="myname"></b><br> Телефон: <b id="mytel"></b></p>
<p> Если вы ошиблись при вводе данных, отправьте заявку еще раз</p> <img src='./content/form/img/thank.png'><button class="cool-form-button" input type="submit" onClick="clearCookies();">Отправить еще раз</button></div>`;
var list = document.querySelectorAll(".cool-form-button");
var index;
var cname = getCookie("fio");
var ctel = getCookie("tel");
for (index = 0; index < list.length; ++index) {
    list[index].disabled = true;
	list[index].innerText = 'Спасибо за заказ'
	setTimeout(function () {
        var list1 = document.querySelectorAll(".modal-dialog");
        for (index = 0; index < list1.length; ++index)
        $('.modal-dialog').replaceWith(str);
        document.getElementById('myname').innerHTML = cname;
        document.getElementById('mytel').innerHTML = ctel; 
    }, 100); // in milliseconds  
}       
}
var today = new Date();
var expiry = new Date(today.getTime() +  24 * 3600 * 1000); // plus 1 day
function setCookie(name, value)
  { 
    document.cookie=name + "=" + escape(value) + "; path=/; expires=" + expiry.toGMTString();
  }
function storeValues(form)  
  {
    setCookie("fio", form.fio.value);
    setCookie("tel", form.tel.value);
      setCookie("sub", form.subidid.value);
    return true;
  }
function getCookie(name)
  {
    var re = new RegExp(name + "=([^;]+)");
    var value = re.exec(document.cookie);
    return (value != null) ? unescape(value[1]) : null;
  }
var expired = new Date(today.getTime() - 24 * 3600 * 1000); // less 24 hours
  function deleteCookie(name)
  {
    document.cookie=name + "=null; path=/; expires=" + expired.toGMTString();
  }
function clearCookies()
  {
    deleteCookie("fio");
    deleteCookie("tel");
      deleteCookie("sub");
    window.location.reload();
  }
